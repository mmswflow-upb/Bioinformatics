Team:

Sakka Mohamad-Mario
Al-Khalidy Essam